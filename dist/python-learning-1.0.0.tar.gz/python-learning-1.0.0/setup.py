from setuptools import setup

setup(
    name='python-learning',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='https://forexample.com',
    license='Free',
    author='satoru',
    author_email='',
    description='Sample package'
)
