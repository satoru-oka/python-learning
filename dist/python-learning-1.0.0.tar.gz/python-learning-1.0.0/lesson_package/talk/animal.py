def sing():
    return 'faldfajdlfja;lj'

def cry():
    return 'fafklajdf;aslfkja'